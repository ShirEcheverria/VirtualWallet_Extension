// chart.js - Creates a D3.js chart from transaction history

// Wait for DOM and D3 to be ready
document.addEventListener("DOMContentLoaded", function() {

    // Check if D3 is loaded
    if (typeof d3 === 'undefined') {
        document.body.innerHTML = '<p style="color: red;">Error: D3.js library not loaded. Please ensure d3.min.js is in the same folder.</p>';
        return;
    }

    // Get transaction history from localStorage using the existing structure
    const fullHistory = JSON.parse(localStorage.getItem("transactionHistoryFull") || "[]");

    if (fullHistory.length === 0) {
        document.body.innerHTML += "<p>No transaction data to display. Add some transactions first!</p>";
        return;
    }

    // Arrays to store BTC and ETH data points, starting at "Start" to force the graph to begin from 0
    const btcData = [{ x: "Start", y: 0, movement: 0 }];
    const ethData = [{ x: "Start", y: 0, movement: 0 }];

    // Track the most recent total balance for each currency
    let totalBTC = 0;
    let totalETH = 0;

    // Process all history entries
    fullHistory.forEach(entry => {
        const time = entry.date;
        if (entry.currency === "BTC") {
            totalBTC = entry.total;
            btcData.push({ x: time, y: totalBTC, movement: entry.amount });
        } else if (entry.currency === "ETH") {
            totalETH = entry.total;
            ethData.push({ x: time, y: totalETH, movement: entry.amount });
        }
    });

    // Create SVG canvas with full size for the standalone chart
    const svgWidth = 900;
    const svgHeight = 650;
    const margin = { top: 150, right: 30, bottom: 100, left: 60 };
    const width = svgWidth - margin.left - margin.right;
    const height = svgHeight - margin.top - margin.bottom;

    const svg = d3.select("body").append("svg")
        .attr("width", svgWidth)
        .attr("height", svgHeight);

    // Group container for the actual graph
    const g = svg.append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Combine BTC and ETH data to define the domain of the x-axis
    const allData = btcData.concat(ethData);

    // X-axis using scalePoint for label-based data (works with date strings)
    const x = d3.scalePoint()
        .domain(allData.map(d => d.x))
        .range([0, width]);

    // Y-axis based on balance values
    const maxValue = d3.max(allData, d => d.y) || 1;
    const y = d3.scaleLinear()
        .domain([0, maxValue * 1.1])
        .range([height, 0]);

    // Add X-axis with rotated labels
    g.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x))
        .selectAll("text")
        .attr("transform", "rotate(-45)")
        .style("text-anchor", "end")
        .style("font-size", "12px");

    // Add Y-axis
    g.append("g").call(d3.axisLeft(y));

    // Define line generator function
    const line = d3.line()
        .x(d => x(d.x))
        .y(d => y(d.y))
        .curve(d3.curveMonotoneX);

    // Draw BTC line (if has data)
    if (btcData.length > 1) {
        g.append("path")
            .datum(btcData)
            .attr("fill", "none")
            .attr("stroke", "orange")
            .attr("stroke-width", 3)
            .attr("d", line);
    }

    // Draw ETH line (if has data)
    if (ethData.length > 1) {
        g.append("path")
            .datum(ethData)
            .attr("fill", "none")
            .attr("stroke", "purple")
            .attr("stroke-width", 3)
            .attr("d", line);
    }

    // Add BTC dots with tooltips
    g.selectAll(".dotBTC")
        .data(btcData)
        .enter().append("circle")
        .attr("class", "dotBTC")
        .attr("cx", d => x(d.x))
        .attr("cy", d => y(d.y))
        .attr("r", 5)
        .attr("fill", "orange")
        .attr("stroke", "#333")
        .attr("stroke-width", 1)
        .append("title")
        .text(d => `BTC\nTotal: ${d.y}\nMovement: ${d.movement}`);

    // Add ETH dots with tooltips
    g.selectAll(".dotETH")
        .data(ethData)
        .enter().append("circle")
        .attr("class", "dotETH")
        .attr("cx", d => x(d.x))
        .attr("cy", d => y(d.y))
        .attr("r", 5)
        .attr("fill", "purple")
        .attr("stroke", "#333")
        .attr("stroke-width", 1)
        .append("title")
        .text(d => `ETH\nTotal: ${d.y}\nMovement: ${d.movement}`);

    // Main title of the graph - bigger and bold
    svg.append("text")
        .attr("x", 30)
        .attr("y", 40)
        .attr("font-size", "24px")
        .attr("font-weight", "bold")
        .attr("fill", "#333")
        .text("Virtual Wallet History");

    // Legend indicators for BTC and ETH - bigger circles, larger font, more spacing
    svg.append("circle")
        .attr("cx", 30)
        .attr("cy", 75)
        .attr("r", 8)
        .style("fill", "orange")
        .style("stroke", "#333")
        .style("stroke-width", 1);

    svg.append("text")
        .attr("x", 45)
        .attr("y", 80)
        .text("BTC")
        .style("font-size", "18px")
        .style("font-weight", "bold")
        .attr("alignment-baseline", "middle");

    svg.append("circle")
        .attr("cx", 130)
        .attr("cy", 75)
        .attr("r", 8)
        .style("fill", "purple")
        .style("stroke", "#333")
        .style("stroke-width", 1);

    svg.append("text")
        .attr("x", 145)
        .attr("y", 80)
        .text("ETH")
        .style("font-size", "18px")
        .style("font-weight", "bold")
        .attr("alignment-baseline", "middle");

    // Fetch current exchange rates and display total values
    if (typeof service !== 'undefined' && service.getLastPriceUSD) {
        service.getLastPriceUSD("BTC").then(btcPrice => {
            service.getLastPriceUSD("ETH").then(ethPrice => {
                const btcValue = (totalBTC * btcPrice).toLocaleString("en-US", {
                    style: "currency",
                    currency: "USD"
                });
                const ethValue = (totalETH * ethPrice).toLocaleString("en-US", {
                    style: "currency",
                    currency: "USD"
                });

                svg.append("text")
                    .attr("x", 30)
                    .attr("y", 110)
                    .attr("font-size", "16px")
                    .style("font-weight", "bold")
                    .attr("fill", "#333")
                    .text(`Total BTC: ${totalBTC} → ${btcValue} | Total ETH: ${totalETH} → ${ethValue}`);
            }).catch(err => {
                console.log("Could not fetch ETH price:", err);
            });
        }).catch(err => {
            console.log("Could not fetch BTC price:", err);
        });
    }

    // Subtitle under totals
    svg.append("text")
        .attr("x", 30)
        .attr("y", 135)
        .attr("font-size", "16px")
        .attr("fill", "#666")
        .text("Balance Evolution Over Time");
});