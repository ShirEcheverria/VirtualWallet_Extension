// Wait until the DOM is fully loaded before running any logic
document.addEventListener("DOMContentLoaded", () => {
    const currency = document.getElementById("currency");
    const amountInput = document.getElementById("amount");

    // Load and display wallet balances (BTC and ETH) from localStorage
    function loadWallet() {
        const BTC = Number(localStorage.getItem("BTC") || 0);
        const ETH = Number(localStorage.getItem("ETH") || 0);
        document.getElementById("wallet-balance").innerHTML =
            `BTC: ${BTC} <br>ETH: ${ETH}`;
    }

    // Load and display transaction history (text log)
    function loadHistory() {
        const list = document.getElementById("history");
        list.innerHTML = "";
        const history = dao.getHistory(); // השתמש בפונקציה שלך
        history.forEach((item, index) => {
            const div = document.createElement("div");
            div.className = "history-item";
            div.textContent = item; // רק הטקסט, ללא כפתור מחיקה
            list.appendChild(div);
        });
    }

    // Save detailed transaction to full history (used for chart) - לא צריך יותר
    // הפונקציה הזאת כבר נכללת בdao._addFullHistory

    // Function to load and display chart inside the extension
    function loadChart() {
        // Clear previous chart if exists
        document.getElementById("chart-area").innerHTML = "";

        // Get transaction history from localStorage
        const history = JSON.parse(localStorage.getItem("transactionHistoryFull")) || [];

        if (history.length === 0) {
            document.getElementById("chart-area").innerHTML = "<p>No data to display.</p>";
            return;
        }

        // Arrays to store BTC and ETH data points
        const btcData = [{ x: "Start", y: 0 }];
        const ethData = [{ x: "Start", y: 0 }];
        let totalBTC = 0;
        let totalETH = 0;

        // Loop through all history and update totals
        history.forEach(entry => {
            const time = entry.date;
            if (entry.currency === "BTC") {
                totalBTC = entry.total;
                btcData.push({ x: time, y: totalBTC, movement: entry.amount });
            } else if (entry.currency === "ETH") {
                totalETH = entry.total;
                ethData.push({ x: time, y: totalETH, movement: entry.amount });
            }
        });

        // Create SVG canvas (adjusted size for popup)
        const svg = d3.select("#chart-area").append("svg").attr("width", 360).attr("height", 400);
        const margin = { top: 80, right: 20, bottom: 60, left: 40 };
        const width = 360 - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;

        // Group container for the actual graph
        const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

        // Combine BTC and ETH data to define the domain of the x-axis
        const allData = btcData.concat(ethData);

        // X-axis using scalePoint for label-based data
        const x = d3.scalePoint()
            .domain(allData.map(d => d.x))
            .range([0, width]);

        // Y-axis based on balance values
        const y = d3.scaleLinear()
            .domain([0, d3.max(allData, d => d.y) * 1.1])
            .range([height, 0]);

        // X-axis with rotated labels (smaller for popup)
        g.append("g").attr("transform", `translate(0,${height})`).call(d3.axisBottom(x))
            .selectAll("text").attr("transform", "rotate(-45)").style("text-anchor", "end").style("font-size", "10px");

        // Add Y-axis
        g.append("g").call(d3.axisLeft(y));

        // Define line generator function
        const line = d3.line().x(d => x(d.x)).y(d => y(d.y));

        // Draw BTC and ETH lines
        g.append("path").datum(btcData).attr("fill", "none").attr("stroke", "orange").attr("stroke-width", 2).attr("d", line);
        g.append("path").datum(ethData).attr("fill", "none").attr("stroke", "purple").attr("stroke-width", 2).attr("d", line);

        // Dots with tooltips for each data point
        g.selectAll(".dotBTC").data(btcData).enter().append("circle").attr("class", "dotBTC").attr("cx", d => x(d.x)).attr("cy", d => y(d.y)).attr("r", 3).attr("fill", "orange")
            .append("title").text(d => `BTC\nTotal: ${d.y}\nMovement: ${d.movement !== undefined ? d.movement : 0}`);

        g.selectAll(".dotETH").data(ethData).enter().append("circle").attr("class", "dotETH").attr("cx", d => x(d.x)).attr("cy", d => y(d.y)).attr("r", 3).attr("fill", "purple")
            .append("title").text(d => `ETH\nTotal: ${d.y}\nMovement: ${d.movement !== undefined ? d.movement : 0}`);

        // Main title of the graph
        svg.append("text").attr("x", 10).attr("y", 20).attr("font-size", "16px").attr("font-weight", "bold").text("Virtual Wallet History");

        // Legend indicators for BTC and ETH (bigger and more spaced)
        svg.append("circle").attr("cx", 15).attr("cy", 45).attr("r", 6).style("fill", "orange");
        svg.append("text").attr("x", 28).attr("y", 49).text("BTC").style("font-size", "16px").style("font-weight", "bold").attr("alignment-baseline","middle");

        svg.append("circle").attr("cx", 100).attr("cy", 45).attr("r", 6).style("fill", "purple");
        svg.append("text").attr("x", 113).attr("y", 49).text("ETH").style("font-size", "16px").style("font-weight", "bold").attr("alignment-baseline","middle");

        // Fetch current exchange rates and show totals
        service.getLastPriceUSD("BTC").then(btcPrice => {
            service.getLastPriceUSD("ETH").then(ethPrice => {
                const btcValue = (totalBTC * btcPrice).toLocaleString("en-US", { style: "currency", currency: "USD" });
                const ethValue = (totalETH * ethPrice).toLocaleString("en-US", { style: "currency", currency: "USD" });

                svg.append("text")
                    .attr("x", 10)
                    .attr("y", 68)
                    .attr("font-size", "12px")
                    .style("font-weight", "bold")
                    .text(`BTC: ${totalBTC} → ${btcValue} | ETH: ${totalETH} → ${ethValue}`);
            });
        });
    }

    // Handle "Add" button: update wallet and logs
    document.getElementById("add").addEventListener("click", () => {
        const value = parseFloat(amountInput.value);
        if (isNaN(value) || value <= 0) return alert("Please enter a valid amount.");

        // השתמש בפונקציה שלך
        dao.add(currency.value, value);

        // Refresh UI
        loadWallet();
        loadHistory();
    });

    // Handle "Remove" button: check balance, update wallet and logs
    document.getElementById("remove").addEventListener("click", () => {
        const value = parseFloat(amountInput.value);
        if (isNaN(value) || value <= 0) return alert("Please enter a valid amount.");

        // Prevent user from removing more than they have
        const available = Number(localStorage.getItem(currency.value)) || 0;
        if (value > available) {
            return alert(`You cannot remove more than you have. ${currency.value} Available: ${available}`);
        }

        // השתמש בפונקציה שלך
        dao.remove(currency.value, value);

        // Refresh UI
        loadWallet();
        loadHistory();
    });

    // Handle "Check This Amount (USD)" button: convert entered amount to USD
    document.getElementById("check").addEventListener("click", () => {
        const value = parseFloat(amountInput.value);
        if (isNaN(value) || value <= 0) return alert("Please enter a valid amount.");

        // Get live price and convert to formatted USD
        service.getLastPriceUSD(currency.value).then(price => {
            const usdValue = (value * price).toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 0, maximumFractionDigits: 0 });
            alert(`${value} ${currency.value} → ${usdValue}`);
        });
    });

    // Handle "Check Wallet Total (USD)" button: show total BTC + ETH value in dollars
    document.getElementById("check-total").addEventListener("click", () => {
        const BTC = Number(localStorage.getItem("BTC") || 0);
        const ETH = Number(localStorage.getItem("ETH") || 0);

        // Fetch current prices and calculate USD value
        service.getLastPriceUSD("BTC").then(btcPrice => {
            service.getLastPriceUSD("ETH").then(ethPrice => {
                const btcValue = BTC * btcPrice;
                const ethValue = ETH * ethPrice;
                const totalUSD = btcValue + ethValue;

                // Display formatted total wallet value
                alert(`Wallet Value:
                    BTC: ${BTC} → ${(btcValue).toLocaleString("en-US", { style: "currency", currency: "USD" })}
                    ETH: ${ETH} → ${(ethValue).toLocaleString("en-US", { style: "currency", currency: "USD" })}
                    Total: ${(totalUSD).toLocaleString("en-US", { style: "currency", currency: "USD" })}`);

            });
        });
    });

    // Handle "Open Chart" button: show chart inside the extension
    document.getElementById("open-chart").addEventListener("click", () => {
        // Hide main container
        document.getElementById("main-container").style.display = 'none';

        // Show chart container
        document.getElementById("chart-container").style.display = 'block';

        // Load chart
        loadChart();
    });

    // Handle back to wallet button
    document.addEventListener("click", (e) => {
        if (e.target.id === "back-to-wallet") {
            // Show main container
            document.getElementById("main-container").style.display = 'block';

            // Hide chart container
            document.getElementById("chart-container").style.display = 'none';
        }
    });

    // Load initial wallet data and history on page load
    loadWallet();
    loadHistory();
});